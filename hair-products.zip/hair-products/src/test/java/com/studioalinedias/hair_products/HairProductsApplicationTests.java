package com.studioalinedias.hair_products;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HairProductsApplicationTests {

	@Test
	void contextLoads() {
	}

}
