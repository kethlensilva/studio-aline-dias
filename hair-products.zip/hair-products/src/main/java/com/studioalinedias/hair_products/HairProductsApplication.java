package com.studioalinedias.hair_products;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HairProductsApplication {

	public static void main(String[] args) {
		SpringApplication.run(HairProductsApplication.class, args);
	}

}
