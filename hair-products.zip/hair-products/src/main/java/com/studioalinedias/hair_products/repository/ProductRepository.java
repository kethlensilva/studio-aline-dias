package com.studioalinedias.hair_products.repository;

import com.studioalinedias.hair_products.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Long> {
}
