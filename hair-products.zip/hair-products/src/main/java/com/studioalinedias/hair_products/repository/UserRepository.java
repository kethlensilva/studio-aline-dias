package com.studioalinedias.hair_products.repository;

import com.studioalinedias.hair_products.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository  extends JpaRepository<User, Long> {
    User findByUsername(String username);
}
