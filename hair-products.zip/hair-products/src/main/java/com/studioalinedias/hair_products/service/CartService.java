package com.studioalinedias.hair_products.service;

import com.studioalinedias.hair_products.model.Cart;
import com.studioalinedias.hair_products.repository.CartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CartService {
    @Autowired
    private CartRepository cartRepository;
    public Cart save(Cart cart) {
        return cartRepository.save(cart);
    }
}
