document.addEventListener('DOMContentLoaded', () => {
    fetch('/cart?userId=1') // Substitua userId pelo ID do usuário logado
        .then(response => response.json())
        .then(data => {
            = document.getElementById('cart');
            data.products.forEach(product => {
                const productDiv = document.createElement('div');
                productDiv.innerHTML = `
                    <h3>${product.name}</h3>
                    <p>${product.description}</p>
                    <p>Price: $${product.price}</p>
                `;
                cart.appendChild(productDiv);
            });
        });
});