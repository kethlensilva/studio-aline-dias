document.addEventListener('DOMContentLoaded', () => {
    fetch('/catalog')
        .then(response => response.json())
        .then(data => {
            const catalog = document.getElementById('catalog');
            data.products.forEach(product => {
                const productDiv = document.createElement('div');
                productDiv.innerHTML = `
                    <h3>${product.name}</h3>
                    <p>${product.description}</p>
                    <p>Price: $${product.price}</p>
                    <button onclick="addToCart(${product.id})">Add to Cart</button>
                `;
                catalog.appendChild(productDiv);
            });
        });
});

function addToCart(productId) {
    fetch('/cart', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `productId=${productId}&userId=1` // Substitua userId pelo ID do usuário logado
    })
    .then(response => {
        if (response.redirected) {
            window.location.href = response.url;
        } else {
            alert('Failed to add to cart');
        }
    });
}